﻿using ClassLibraryPopryzhenok.Models;

namespace ClassLibraryPopryzhenok.Utils
{
    public class AppData
    {
        public static PopryzhenokEntities db = new PopryzhenokEntities();
    }
}