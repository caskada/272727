# Popryzhenok_Subbotina
Как запустить проект

1. Склонировать проект
2. Запустить MS SQL Server Management Studio 18.8
3. В окне "Имя сервера" ввести: (localdb)\MSSQLLocalDB, нажать Connect
4. Нажать "New Query"
5. Скопировать содержимое файла Popryzhenok_Subbotina.sql
6. Нажать F5. База данных создана и заполнена данными
7. В Visual Studio с открытым склонированным нажать F5
8. Наслаждаться дизайном
